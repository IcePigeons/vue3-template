import { useVant } from "./vant";

export default {
  pages: ["pages/index/index"],
  window: {
    backgroundTextStyle: "light",
    navigationBarBackgroundColor: "#fff",
    navigationBarTitleText: "WeChat",
    navigationBarTextStyle: "black",
  },
  usingComponents: {
    ...useVant("button"),
    // "van-button": "./components/vant-weapp/dist/button/index",
  },
};
